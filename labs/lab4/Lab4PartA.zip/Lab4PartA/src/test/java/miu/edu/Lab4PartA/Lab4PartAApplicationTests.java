package miu.edu.Lab4PartA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab4PartAApplicationTests {

	@Test
	void contextLoads() {
	}

}
