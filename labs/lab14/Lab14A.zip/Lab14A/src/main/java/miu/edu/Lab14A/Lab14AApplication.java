package miu.edu.Lab14A;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab14AApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab14AApplication.class, args);
	}

}
