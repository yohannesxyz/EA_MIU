package miu.edu.Lab14A;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab14AApplicationTests {

	@Test
	void contextLoads() {
	}

}
