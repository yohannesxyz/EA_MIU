package specifications;

import domain.CD;
import org.springframework.data.jpa.domain.Specification;

public class CDSpecification {
    public static Specification<CD> hasArtistAndPriceGreaterThan(String artist, double price) {
        return (root, query, criteriaBuilder) ->
                criteriaBuilder.and(
                        criteriaBuilder.equal(root.get("artist"), artist),
                        criteriaBuilder.greaterThan(root.get("price"), price)
                );
    }
}
