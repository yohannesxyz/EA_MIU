package repositories;

import domain.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
    List<Customer> findAll();
    List<Customer> findByAddress_Zip(String zip);
    List<Customer> findByTheOrders_Orderlines_Product_Name(String productName);
    List<Customer> findByAddress_Country(String country);
}
