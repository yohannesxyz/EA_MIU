package repositories;

import domain.CD;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CDRepository extends JpaRepository<CD, Long> {
    List<CD> findByArtistAndPriceLessThan(String artist, double price);
    List<CD> findByArtist(String artist);
    List<CD> findByArtistAndPriceGreaterThan(String artist, double price);
}
