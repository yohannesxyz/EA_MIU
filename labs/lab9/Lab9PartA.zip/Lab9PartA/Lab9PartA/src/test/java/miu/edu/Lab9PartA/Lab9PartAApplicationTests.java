package miu.edu.Lab9PartA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab9PartAApplicationTests {

	@Test
	void contextLoads() {
	}

}
