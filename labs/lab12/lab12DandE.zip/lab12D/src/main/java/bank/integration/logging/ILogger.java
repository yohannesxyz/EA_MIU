package bank.integration.logging;

public interface ILogger {
    public void log (String logstring);
}
