package miu.edu.Lab13PartA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab13PartAApplicationTests {

	@Test
	void contextLoads() {
	}

}
