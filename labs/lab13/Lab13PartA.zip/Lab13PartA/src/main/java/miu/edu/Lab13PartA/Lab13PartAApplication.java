package miu.edu.Lab13PartA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab13PartAApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lab13PartAApplication.class, args);
	}

}
